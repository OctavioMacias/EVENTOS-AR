<?php 
	
	phpinfo();

?>