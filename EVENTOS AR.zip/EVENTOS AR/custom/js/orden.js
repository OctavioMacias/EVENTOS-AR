function getClienteDatos(){

		var clientId = $("#codCte").val();
		
		if(clientId == "" ){
			$("#clientName").val("");
			$("#clientCat").val("");
		}else{

			$.ajax({
				url: 'php_action/fetchSelectedClient.php',
				type: 'post',
				data: {clientId : clientId},
				dataType: 'json',
				success:function(response) {
					//var categoria = response.categoria == 1 ? 'ORO' : response.categoria == 2 ? 'PLATA' : 'BRONCE'; 
					var categorias = {1: 'FRECUENTE', 2: 'NUEVO'};
					$("#clientName").val(response.nombre_cte);
					//$("#clientCat").val(categoria);
					$('#clientCat').val(categorias[response.categoria]);
					$('#clientCatHi').val(categorias[response.categoria]);
					$("#clientObser").val(response.comentario);
					
				}//Success ajax
			
			});// /ajax function to fetch the product data	
		}
		
}//End GetClientData

function getProductoData(row = null){

	if (row) {
		var productId = $("#codProd"+row).val();

		if(productId == "" ){
			$("#productName"+row).val("");
			$("#rate"+row).val("");
			$("#quantity"+row).val("");
			$("#total"+row).val("");
		}else{
			$.ajax({
				url: 'php_action/fetchSelectedProduct.php',
				type: 'post',
				data: {productId : productId},
				dataType: 'json',
				success:function(response) {
					$("#statusProd"+row).val(response.estado);
								

					if($("#statusProd"+row).val() == 1 && $("#clientCatHi").val() == 'NUEVO'){

						$("#productName"+row).val(response.nombre);
						$("#rate"+row).val(response.nuevo);
						$("#rateValue"+row).val(response.nuevo);
						$("#quantity"+row).val(1);

						var total = Number(response.nuevo) * 1;
						total = total.toFixed(2);
						$("#total"+row).val(total);
						$("#totalValue"+row).val(total);

     					
					} else if($("#statusProd"+row).val() == 1 && $("#clientCatHi").val() == 'FRECUENTE'){

						$("#productName"+row).val(response.nombre);
						$("#rate"+row).val(response.precio);
						$("#rateValue"+row).val(response.precio);
						$("#quantity"+row).val(1);

						var total = Number(response.precio) * 1;
						total = total.toFixed(2);
						$("#total"+row).val(total);
						$("#totalValue"+row).val(total);
					
					} 

					else{
						alertify.alert("Producto No Existe o Eliminado");
						$("#statusProd"+row).val("");
						$("#codProd"+row).val("");
					
					}
					
					
					subAmount();
				}//Success ajax
			});// /ajax function to fetch the product data	
		}
		

	}else{
		alert('Error !! Actualizar la Pagina (F5)');
	}//else

}//End getProductData