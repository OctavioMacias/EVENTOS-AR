function calcular() {
    // obtenemos todas las filas del tbody
    var filas=document.querySelectorAll("#productTable tbody tr");
 
    var total=0;
 
    // recorremos cada una de las filas
    filas.forEach(function(e) {
 
        // obtenemos las columnas de cada fila
        var columnas=e.querySelectorAll("td");
 
        // obtenemos los valores de la cantidad y importe
        var precio=parseFloat(columnas[3].textContent);
        var cantidad=parseFloat(columnas[4].textContent);
 
        // mostramos el total por fila
        columnas[5].textContent=(cantidad*importe).toFixed(2);
 
        total+=cantidad*importe;
    });
 
