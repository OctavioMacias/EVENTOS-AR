export default {

    database: {
        host: 'localhost',
        user: 'root',
        password: 'whateverpass',
        database: 'ng_games'
    }

}